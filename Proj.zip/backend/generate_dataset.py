"""
AI FraudShield — Synthetic Dataset Generator
=============================================
Generates ~15,000 realistic transaction records with 5 behavioural
features and a binary fraud_label target.

Distribution: ~90 % legitimate, ~10 % fraudulent.
Fraudulent patterns: high amount vs. avg, new recipients, unusual hours,
high velocity.  Intentional noise/overlap so the model must learn.
"""

import numpy as np
import pandas as pd
import os

SEED = 42
N_TOTAL = 15_000
FRAUD_RATIO = 0.10

rng = np.random.default_rng(SEED)


def generate_dataset() -> pd.DataFrame:
    n_fraud = int(N_TOTAL * FRAUD_RATIO)
    n_legit = N_TOTAL - n_fraud

    rows = []

    # ── Legitimate transactions ──────────────────────────────────
    for _ in range(n_legit):
        user_avg = rng.uniform(1000, 20000)
        # Most legitimate transactions are near the user's average
        amount = max(100, rng.normal(loc=user_avg, scale=user_avg * 0.4))
        new_recip = int(rng.random() < 0.15)          # 15 % chance new recipient
        freq = max(1, int(rng.normal(loc=5, scale=2)))  # ~5 tx in window
        hour = int(rng.choice(
            np.concatenate([
                rng.normal(loc=14, scale=3, size=80).clip(8, 21),   # 80 % daytime
                rng.uniform(0, 24, size=20),                         # 20 % any hour
            ])
        )) % 24

        rows.append({
            'transaction_amount':   round(amount, 2),
            'user_avg_amount':      round(user_avg, 2),
            'new_recipient':        new_recip,
            'transaction_frequency': freq,
            'transaction_hour':     hour,
            'fraud_label':          0,
        })

    # ── Fraudulent transactions ──────────────────────────────────
    for _ in range(n_fraud):
        user_avg = rng.uniform(1000, 20000)

        # Pattern mix — not all fraud looks the same
        pattern = rng.choice(['high_amount', 'velocity', 'mixed'], p=[0.45, 0.20, 0.35])

        if pattern == 'high_amount':
            multiplier = rng.uniform(3, 25)
            amount = user_avg * multiplier
            new_recip = int(rng.random() < 0.80)
            freq = max(1, int(rng.normal(loc=7, scale=3)))
            hour = int(rng.choice(
                np.concatenate([
                    rng.uniform(0, 6, size=60),     # heavy night bias
                    rng.uniform(6, 24, size=40),
                ])
            )) % 24

        elif pattern == 'velocity':
            amount = max(100, rng.normal(loc=user_avg * 1.5, scale=user_avg * 0.5))
            new_recip = int(rng.random() < 0.60)
            freq = max(8, int(rng.normal(loc=15, scale=4)))   # very high velocity
            hour = int(rng.uniform(0, 24)) % 24

        else:  # mixed
            multiplier = rng.uniform(2, 10)
            amount = user_avg * multiplier
            new_recip = int(rng.random() < 0.70)
            freq = max(1, int(rng.normal(loc=10, scale=4)))
            hour = int(rng.choice(
                np.concatenate([
                    rng.uniform(22, 30, size=50) % 24,  # late-night wrap
                    rng.uniform(0, 24, size=50),
                ])
            )) % 24

        rows.append({
            'transaction_amount':   round(amount, 2),
            'user_avg_amount':      round(user_avg, 2),
            'new_recipient':        new_recip,
            'transaction_frequency': freq,
            'transaction_hour':     hour,
            'fraud_label':          1,
        })

    df = pd.DataFrame(rows)
    df = df.sample(frac=1, random_state=SEED).reset_index(drop=True)
    return df


if __name__ == '__main__':
    out_path = os.path.join(os.path.dirname(__file__), 'dataset.csv')
    df = generate_dataset()
    df.to_csv(out_path, index=False)

    total   = len(df)
    n_fraud = df['fraud_label'].sum()
    print(f'Dataset generated: {total} rows')
    print(f'  Legitimate : {total - n_fraud}  ({(total - n_fraud)/total*100:.1f}%)')
    print(f'  Fraudulent : {n_fraud}  ({n_fraud/total*100:.1f}%)')
    print(f'Saved to {out_path}')
